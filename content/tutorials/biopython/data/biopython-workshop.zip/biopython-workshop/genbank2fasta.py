#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Oct 11 16:06:33 2020
Python 3

Biopython workshop

@author: khs3z
"""

from Bio import Entrez

Entrez.email = "khs3z@virginia.edu" # provide your email address 
from Bio import SeqIO

gb_file = 'HsPax6-208879460-nucleotide.gb'
with open(gb_file) as f:
    gb_generator = SeqIO.parse(f, format='gb')
    for entry in gb_generator:
        with open(f'Hs-pax6-{entry.id}-nucleotide.fasta', 'w') as fileout:
            SeqIO.write(entry, fileout, 'fasta')
