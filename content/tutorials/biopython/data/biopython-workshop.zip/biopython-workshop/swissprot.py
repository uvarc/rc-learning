#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Oct 11 23:38:39 2020
Python 3

Biopython workshop

@author: khs3z
"""

from Bio import ExPASy
from Bio import SeqIO

with ExPASy.get_sprot_raw("P26367") as handle:
    seq_record = SeqIO.read(handle, "swiss")
print(seq_record.id)
print(seq_record.name)
print(seq_record.description)
print(repr(seq_record.seq))
print("Length %i" % len(seq_record))
print(seq_record.annotations["keywords"])