#include <vector>

class Fraction {
    private:
    int num, denom;

    public:
    Fraction(int numerator, int denominator);
    std::vector<int> addFracs(Fraction f2);

};

