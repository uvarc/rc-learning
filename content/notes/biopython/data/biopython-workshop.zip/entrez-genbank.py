#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Oct 11 15:30:24 2020
Python 3

Biopython workshop

@author: khs3z
"""

from Bio import Entrez

Entrez.email = "ksiller@gmail.com"
handle = Entrez.esearch(db="nucleotide", term = ["Homo sapiens[Orgn] AND pax6[Gene]"], retmax=5, usehistory="y")
record = Entrez.read(handle)
handle.close()
for k,v in record.items():
    print (k,v)

# iterate over ids in list
for seq_id in record["IdList"]:
    # get entry from Entrez
    print (seq_id)
    handle = Entrez.efetch(db="nucleotide", id=seq_id, rettype="gb", retmode="text")
    result = handle.read()
    handle.close()
    # save
    filename = f"HsPax6-{seq_id}-nucleotide.gb"
    print ("Saving to file:", filename)
    with open(filename, 'w') as fastafile:
        # append fasta entry
        fastafile.write(result.rstrip()+"\n")

print ("Done")