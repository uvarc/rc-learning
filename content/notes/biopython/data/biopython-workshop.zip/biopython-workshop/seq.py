#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Oct 11 14:46:33 2020
Python 3

Biopython workshop

@author: khs3z
"""

from Bio.Seq import Seq

my_dna = Seq("ATGAGTACACTATAGA")
print (my_dna)
# find position of first subsequence
print (my_dna.find("TAC"))
print (my_dna.find("AC"))
print (my_dna.find("CTC"))

# count
print ("A count:", my_dna.count("A"))
print ("AC count:", my_dna.count("AC"))
print ("AA count:", Seq("AAAA").count("AA")) # non-overlapping

# complement and reverse complement
compl = my_dna.complement()
rev_compl = my_dna.reverse_complement()
print ("original: \t", my_dna)
print ("complement:\t", compl)
print ("rev complement:\t", rev_compl)

# transcription
my_rna = my_dna.transcribe()
print ("RNA:", my_rna)

# translation
my_peptide = my_dna.translate()
print ("Peptide:", my_peptide)

mutable_dna = my_dna.tomutable()
mutable_dna[2] = 'A' # this works
print (my_dna)
print (mutable_dna)