#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Oct 11 14:12:35 2020
Python 3

Biopython workshop

@author: khs3z
"""

from Bio import SeqIO

file = open('HsPax6-protein.fasta') 
fastarecords = SeqIO.parse(file, "fasta")
# create a list of SeqRecords
fastalist = [entry for entry in fastarecords]
# iterate over fasta entries
for entry in fastalist:
    print (f"ID={entry.id}")
    print (f"Name={entry.name}")
    print (f"Description={entry.description}")
    print (f"Seq length={len(entry.seq)}")
    print (f"Features={entry.features}")  # empty for Fasta format
    print (f"Sequence={entry.seq}\n")

# filter list of records
sublist = [e for e in fastalist if len(e.seq) < 300]
print (f"Total number of sequences: {len(fastalist)}")
print (f"Number of sequences (<300 aa): {len(sublist)}")

