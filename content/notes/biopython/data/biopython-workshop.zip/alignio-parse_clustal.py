#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 12 00:15:07 2020
Python 3

Biopython workshop

@author: khs3z
"""

from Bio import AlignIO

inputfile = open("Pax6-multispec-protein.aln", "r")
# assuming single alignment in file; use AlignIO.parse for multiple alignments 
alignment = AlignIO.read(inputfile, "clustal")
inputfile.close()
print ("Alignment length:", alignment.get_alignment_length())
print (alignment,"\n")

# update identifier
species = ['H.sapiens', 'M.musculus', 'X.tropicalis', 'T.rubripes', 'D.rerio', 'D.rerio', 'D.melanogaster', 'D.melanogaster']
for idx,line in enumerate(alignment):
    line.id = f"{species[idx]}:{line.id}"
print (alignment)

# slice: first axis defines line, second axis defines column index (zero-indexed)
# get lines 1-6, first 50 columns
subset = alignment[:6,:50]
print (subset)

# join two alignment blocks
edited = alignment[:,:50] + alignment[:,500:]
print (edited)

# save as Stockholm
with open("Pax6-multispec-protein.sth", "w") as outputfile:
    AlignIO.write(alignment, outputfile, "stockholm")

# get alignment as formatted string
print ("Formatted Alignment:")
print (format(alignment, "clustal"))
print (type(alignment))
