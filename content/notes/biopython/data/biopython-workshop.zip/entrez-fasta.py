#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Oct 10 15:54:07 2020
Python 3

Biopython workshop

@author: khs3z
"""

from Bio import Entrez

Entrez.email = "ksiller@gmail.com"
handle = Entrez.esearch(db="protein", term = ["Homo sapiens[Orgn] AND pax6[Gene]"], usehistory="y")
record = Entrez.read(handle)
handle.close()
for k,v in record.items():
    print (k,v)

# fetch up to retmax (default=20) records using id list
handle = Entrez.efetch(db="protein", rettype="fasta", retmode="text", id=record["IdList"])

# Alternative: fetch all records using search history
# handle = Entrez.efetch(db="protein", rettype="fasta", retmode="text", webenv=record["WebEnv"], query_key=record["QueryKey"])

result = handle.read()  # return tryp is simple string
handle.close()
# remove empty lines
fastaseq = result.replace("\n\n","\n")
with open('HsPax6-protein.fasta', 'w') as f:
   f.write(fastaseq)

print ("Done")