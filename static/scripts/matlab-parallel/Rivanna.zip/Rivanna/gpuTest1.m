function  [a_cpu]=gpuTest1(ndim,nloop,jobid)
% Example to test gpu nodes
% ndim: dimension of matrix
% jobid: Slurm job id  for save saving output to job specific file
% nloop is number of time for parallel loop to run

% Check to see if you have a GPU device on your machine:
disp(['number of gpus ', num2str(gpuDeviceCount)])

% Create pool of workers across the gpus
parpool('local',gpuDeviceCount);

% Display the gpus
spmd
   gpuDevice
end

% preallocate output gpu array
a=zeros(nloop, 1,'double','gpuArray');

tic
parfor k=1:nloop
% create random 2-D array on gpu, perform 2-D fft and get maximum value
a(k) = max(max(abs(fft2((rand(ndim,'double','gpuArray'))))));
end

%Wait for the transfer to complete:
wait(gpuDevice)

%Gather the results from the GPU back to the CPU:
a_cpu = gather(a);
firstTen=a_cpu(1:10)  % Display first 10 elements of output array

delete(gcp('nocreate')); % delete parallel pool
tGPU = toc;
disp(['Total time on GPU: ' num2str(tGPU)])
disp(['ndim = ', num2str(ndim), '   nloop = ', num2str(nloop)])

% save output to file
save(['gpuTest1_' jobid '.out'],...
    'tGPU','ndim','nloop','firstTen','-ascii');

end
