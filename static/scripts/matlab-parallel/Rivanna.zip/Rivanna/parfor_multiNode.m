% Create a cluster object based on the profile
pc = parcluster('rivanna R2020a'); % This must correspond to the matlab
     % version you are using

% Add additional properties related to slurm job parameters
pc.AdditionalProperties.AccountName = 'hpc_build' % account to charge job to
pc.AdditionalProperties.QueueName = 'parallel' % queue to submit job to
pc.AdditionalProperties.WallTime = '1:00:00' % amount of wall time needed
pc.saveProfile % save settings
pc.AdditionalProperties  % confirm above properties are set

% Additional configuration commands

% email address for Slurm to send email
pc.AdditionalProperties.EmailAddress ='teh1m@virginia.edu'
% send email when job ends
pc.AdditionalProperties.AdditionalSubmitArgs ='--mail-type=end'

% specify the total number of processes
% and number of processes (cores) per node
procs=8;
procsPerNode=4;
pc.AdditionalProperties.ProcsPerNode=procsPerNode;

% Launch Matlab parallel code across two compute nodes
j=pc.batch(@pcalc2Test1,1,{400,400,'myOutput1'},'pool',procs-1);

% Arguments of c.batch in order

% Handle of function containing parallel code to run
% Number of function outputs
% Cell array of function inputs
% Setting of a pool of matlab workers
% Number of Matlab workers. There are 8 cores on two nodes
% so use 7 for workers and one for master

% Get the state of the job
j.State

% Don't return command prompt until job finishes
j.wait

% Get output from the job
j.fetchOutputs

% Command to use to get back debug information if a job crashes
% For parallel jobs (i.e. calling batch with pool>0)
j.Parent.getDebugLog(j)

