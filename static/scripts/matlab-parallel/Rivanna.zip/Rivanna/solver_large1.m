function [ firstTenX, errChk2 ] = solver_large1( N, jobid)
% This function is a simple test of a LU linear solver
% Since b is sum of columns, x should always be a vector
% of ones.

tic;
spmd
    A = codistributed.rand(N, N);
    b = sum(A, 2);

    % solve Ax=b
    x = A\b;

    % Check error
    errChk = normest(A * x - b);
end
time=toc;

x2 = gather(x);
fprintf('norm of the error for the solution \n')
errChk2=gather(errChk)
fprintf('first 10 elements of solution vector (should be all ones)\n')
firstTenX=x2(1:10)
time

% save output to file
save(['solver_large1_' num2str(jobid) '.out'],...
    'time','errChk2','firstTenX','-ascii');

end
