% create a cluster object
pc = parcluster('rivanna R2020a'); % This must correspond to the matlab
     % version you are using
pc.AdditionalProperties.AccountName = 'hpc_build'
pc.AdditionalProperties.WallTime = '01:00:00';
pc.AdditionalProperties.QueueName = 'parallel';

% email address for Slurm to send email
pc.AdditionalProperties.EmailAddress ='teh1m@virginia.edu'
% send email when job ends
pc.AdditionalProperties.AdditionalSubmitArgs ='--mail-type=end'

% specify the total number of processes
% and number of processes (cores) per node
procs=8;
procsPerNode=4;
pc.AdditionalProperties.ProcsPerNode=procsPerNode;
pc.saveProfile;

% specify additional submit arguments
pc.AdditionalProperties.AdditionalSubmitArgs='--mem-per-cpu=30000';

% start the matlabpool with available workers
% control how many workers by setting ntasks in your sbatch script

j=pc.batch(@solver_large1,2,{20000,'myOutput2'},'Pool',procs-1);

wait(j);
j.State
j.fetchOutputs{:}

% Command to use to get back debug information if a job crashes
% For parallel jobs (i.e. calling batch with pool>0)
j.Parent.getDebugLog(j)
