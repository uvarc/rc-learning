% The following set of commands are for running parallel Matlab programs
% across multiple compute nodes of the Rivanna cluster.

% Load the module for Matlab from the Linux command line.
% module load matlab

% The following commands are executed from within Matlab

% set up initial configuration for running multi-node Matlab parallel jobs
% on Rivanna. This just needs to be done once, and its saved in Matlab’s
% parallel profiles.

configCluster % the configuration created is specific to the Matlab version
