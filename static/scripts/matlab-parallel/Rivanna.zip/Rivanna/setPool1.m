% Script setPool1.m
% create a local cluster object
pc = parcluster('local');

% explicitly set JobStorageLocation to job-specific temp directory
mkdir(strcat('/scratch/',getenv('USER'),'/slurmJobs/',getenv('slurm_ID')));
pc.JobStorageLocation = ...
     strcat('/scratch/', getenv('USER'),'/slurmJobs/', getenv('slurm_ID'));

% start the matlabpool with the available workers
% control how many workers by setting ntasks in your sbatch script
parpool(pc, str2num(getenv('numWorkers')))

