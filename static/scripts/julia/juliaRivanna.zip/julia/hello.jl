msg="hello world"
println(msg)
