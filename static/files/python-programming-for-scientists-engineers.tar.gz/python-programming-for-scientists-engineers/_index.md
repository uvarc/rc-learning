---
# Course title, summary, and position.
linktitle: Programming in Python for Scientists and Engineers
summary: An introduction to Python with an emphasis on scientific and engineering applications.
authors: [kah,jmh]
categories: ["Python","Programming"]
tags: ["python","programming"]

# Page metadata.
title: Programming in Python for Scientists and Engineers
date: "2018-09-09T00:00:00Z"
lastmod: "2018-09-09T00:00:00Z"
draft: false 
toc: false 
type: docs  # Do not modify.

# Add menu entry to sidebar.
# - name: Declare this menu item as a parent with ID `name`.
# - weight: Position of link in menu.
menu:
    python-programming-for-scientists-engineers:
       name: Programming in Python for Scientists and Engineers
       weight: 1
---

This video course is an introduction to the Python programming language that is particularly appropriate for scientists and engineers.  No previous experience with programming is required.

