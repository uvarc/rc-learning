---
title: Introduction to QIIME 2
date: 2025-06-13T00:00:00-05:00
type: docs 
weight: 1 

menu: 
    qiime2:
---


In this tutorial, we will be discussing the following topics:
* What is QIIME 2
* How to import data into QIIME 2
* How to view QIIME 2 results
