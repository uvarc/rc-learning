---
title: Need help?
date: 2023-12-11T21:14:11-14:00
type: docs 
weight: 3000
menu: 
    hpc-command-line:
---

Research Computing is ready to help you learn to use our systems efficiently.  You can [submit a ticket](https://www.rc.virginia.edu/form/support-request/).  For in-person help, please attend one of our weekly sessions of [office hours](https://www.rc.virginia.edu/support/#office-hours).
