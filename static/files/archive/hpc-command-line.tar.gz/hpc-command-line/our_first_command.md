---
title: Our First Command
date: 2023-12-11T21:14:11-14:00
type: docs 
weight: 500
menu: 
    hpc-command-line:
---

Let’s run our first command. Into a terminal type
```bash
$pwd
/home/mst3k
```
This command stands for *p*rint *w*orking *d*irectory.  It prints the name of the folder in which the shell is currently working.
