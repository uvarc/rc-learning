---
title: Exercise 1
date: 2023-12-11T21:14:11-14:00
type: docs 
weight: 850
menu: 
    hpc-command-line:
---

Start a terminal on a frontend by whatever means you prefer. Type (the `$` is the prompt and is not typed):

```bash
$echo $SHELL
$pwd
$mkdir test_dir
$cd test_dir
$ls ..
$mkdir sub_dir
$ls
```

What is the full path of your home directory?

Delete the `sub_dir` folder.

Copy the directory
```no-highlight
/share/resources/tutorials/rivanna-cli/shakespeare
```
into your home directory.
